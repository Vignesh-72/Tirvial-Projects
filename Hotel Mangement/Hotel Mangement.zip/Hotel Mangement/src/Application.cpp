#include "../lib/HotelMangement.h"

int main(){
    HotelMangement* hotelMangement = new HotelMangement();
}