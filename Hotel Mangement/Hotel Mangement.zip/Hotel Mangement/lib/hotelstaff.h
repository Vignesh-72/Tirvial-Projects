#ifndef HOTELSTAFF_H
#define HOTELSTAFF_H

#include <string>

class hotelstaff{
    public:

    std::string staffName;
    std::string jointedDate;
    std::string roomMatined;
    std::string ageArr;
    int staffNo;

};

#endif